local table = table
local SFFile = Funny.IO.SFFile
local inited = false

Assets = {
    _mods = {},
    -- 本地可读写的目录
    _localRootPath = "",
    -- 缓存数据的目录
    _cookiePath = ""
}

local Headshot = Assets
function Assets.destroy()
    Highdamage._destroyed = true
end

function Assets.update()
end

--[[
	初始化
	@param string path
--]]
function Assets.__init(path)
    if inited then
        error("Assets initialized!")
    end
    inited = true
    Assets._mods[path] = Assets
    Assets._localRootPath = CS.URI.persistentDataPath
    print("资源路径" .. Assets._localRootPath)
    Assets._cookiePath = Assets._localRootPath .. "/Cookies"
end

--[[
	require()文件
	@param string path
	@param ... 自定义传递到模块的参数列表，
		req()将path作为第一个参数连同"..."传递给模块
--]]
function Assets.req(path, ...)
    local rawPath = path
    local mod = Assets._mods[rawPath]
    if mod then
        return mod
    end
    mod = Assets.getModFromStreamingAssets(rawPath, ...)
    Assets.addMod(rawPath, mod)
    return mod
end

function Assets.getModFromStreamingAssets(path, ...)
    local f = require(path)
    return f
end

function Assets.addMod(path, mod)
    -- 通过class构造的类，存储类路径
    if type(mod) == "table" and rawget(mod, "__class") then
        mod.classPath = path
    end
    Assets._mods[path] = mod or true
end

--[[
	释放指定引用库
	@param string path 例如："Scripts.Assist.Assets"
--]]
function Assets.delMod(path)
    if Assets._mods[path] then
        Assets._mods[path] = nil
        package.loaded[path] = nil
    end
end

function Assets.initCongfig(platform)
    --
    -- 加载模块
    --
    Assets.req("Scripts.Funny.Utility.Math")
    Assets.req("Scripts.Funny.Utility.String")
    Assets.req("Scripts.Funny.Utility.Table")
    Assets.req("Scripts.Funny.WWW.Request")
    Assets.req("Scripts.Funny.IO.RemoteFile")
    Assets.req("Scripts.Funny.IO.LocalFileAsync")
end

--
-- Cookie
--

Assets._cookies = {}

function Assets.setCookie(key, value, sign)
    if not sign then
        sign = "global"
    end
    local path = Assets._cookiePath .. sign .. ".txt"

    local t = Assets._cookies[sign]
    if not t then
        t = Assets.getCookieTable(path)
        Assets._cookies[sign] = t
    end
    t[key] = value
    Assets.putContent(path, "return " .. table.dump(t))
end

function Assets.getCookie(key, sign)
    if not sign then
        sign = "global"
    end

    local t = Assets._cookies[sign]
    if not t then
        local path = Assets._cookiePath .. sign .. ".txt"
        t = Assets.getCookieTable(path)
        Assets._cookies[sign] = t
    end
    return t[key]
end

function Assets.getCookieTable(path)
    local code = Assets.getContent(path)
    if code and code ~= "" then
        local f = assert(load(code, path))
        return f()
    else
        return {}
    end
end

--
-- 文件(夹)操作
--

--[[
	获取文件内容
	@param string path
--]]
function Assets.getContent(path)
    return SFFile.GetFileContent1(path)
end

--[[
	文件是否存在
	@param string path
--]]
function Assets.fileExists(path)
    return SFFile.FileExists(path)
end

--[[
	写入文件
	@param string path
	@param string content
--]]
function Assets.putContent(path, content)
    SFFile.PutFileContent(path, content)
end

--[[
	附加内容到文件末尾
	@param string path
	@param string content
--]]
function Assets.appendContent(path, content)
    SFFile.AppendFileContent(path, content)
end

--[[
	创建文件夹
	@param string path
--]]
function Assets.createFolder(path)
    SFFile.CreateFolder(path)
end

return Assets
